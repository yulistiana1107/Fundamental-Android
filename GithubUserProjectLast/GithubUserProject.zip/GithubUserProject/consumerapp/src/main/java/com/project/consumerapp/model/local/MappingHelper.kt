package com.project.consumerapp.model.local

import android.database.Cursor
import com.project.consumerapp.model.data.User
import com.project.consumerapp.model.local.DatabaseContract

object MappingHelper {

    fun mapCursorToArrayList(cursor: Cursor?): ArrayList<User> {
        val list = ArrayList<User>()
        if (cursor != null) {
            while (cursor.moveToNext()) {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContract.FavoriteUserColumns.ID))
                val username = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.USERNAME))
                val avatarUrl = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.AVATAR_URL))
                val detail = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.DETAIL))
                val followers = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.FOLLOWERS))
                val following = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.FOLLOWING))
                val workplace = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.WORKPLACE))
                val location = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.LOCATION))
                val repositories = cursor.getString(cursor.getColumnIndex(DatabaseContract.FavoriteUserColumns.REPOSITORIES))

                list.add(
                        User(
                                username,
                                detail,
                                avatarUrl,
                                id,
                                followers,
                                following,
                                workplace,
                                location,
                                repositories
                        )
                )
            }
        }
        return list
    }
}