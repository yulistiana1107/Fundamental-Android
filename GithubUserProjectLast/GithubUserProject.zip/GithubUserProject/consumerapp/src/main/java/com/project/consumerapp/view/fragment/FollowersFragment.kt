package com.project.consumerapp.view.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.consumerapp.R
import com.project.consumerapp.model.data.User
import com.project.consumerapp.view.main.FullProfileActivity
import com.project.consumerapp.view.main.MainActivity
import com.project.consumerapp.viewmodel.MainViewModel
import com.project.consumerapp.viewmodel.MyAdapter
import kotlinx.android.synthetic.main.fragment_followers.*


class FollowersFragment(private val username: String) : Fragment() {
    companion object {
        const val EXTRA_DETAIL2 = "extra_detail"
    }

    private lateinit var adapter: MyAdapter
    private lateinit var mainViewModel: MainViewModel

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_followers, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = MyAdapter()
        mainViewModel = ViewModelProvider(
                this, ViewModelProvider.NewInstanceFactory()
        ).get(MainViewModel::class.java)

        activity!!.intent.getParcelableExtra<User>(EXTRA_DETAIL2)
        config()
        onClicked()

        mainViewModel.getDataFollowers(activity!!.applicationContext, username)
        showLoading(true)

        mainViewModel.getListUsers().observe(activity!!, Observer {followerItems ->
            if (followerItems != null) {
                adapter.setData(followerItems)
                showLoading(false)
            }
        })
    }


    fun onClicked(){
        adapter.setOnItemClickCallBack(object : MyAdapter.OnItemClickCallback {
            override fun onItemClicked(user: User) {
                activity?.let{
                    val intent = Intent (it, FullProfileActivity::class.java)
                    intent.putExtra(MainActivity.EXTRA_USER, user)
                    intent.putExtra(FullProfileActivity.EXTRA_USERNAME, user.name)
                    intent.putExtra(FullProfileActivity.EXTRA_ID, user.id)
                    intent.putExtra(FullProfileActivity.EXTRA_URL, user.photo)
                    intent.putExtra(FullProfileActivity.EXTRA_NAME, user.detail)
                    it.startActivity(intent)
                }
            }
        })
    }

    private fun config() {
        recyclerviewfollowers.layoutManager = LinearLayoutManager(activity)
        recyclerviewfollowers.setHasFixedSize(true)
        recyclerviewfollowers.adapter = adapter
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar1.visibility = View.VISIBLE
        } else {
            progressBar1.visibility = View.INVISIBLE
        }
    }
}