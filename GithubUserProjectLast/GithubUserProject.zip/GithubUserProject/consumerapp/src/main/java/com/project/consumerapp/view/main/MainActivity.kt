package com.project.consumerapp.view.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.consumerapp.databinding.ActivityMainBinding
import com.project.consumerapp.model.data.User
import com.project.consumerapp.viewmodel.FavoriteViewModel
import com.project.consumerapp.viewmodel.MyAdapter

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_USER = "extra_user"
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MyAdapter
    private lateinit var viewModel: FavoriteViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter= MyAdapter()
        adapter.notifyDataSetChanged()

        viewModel = ViewModelProvider(this).get(FavoriteViewModel::class.java)


        binding.apply {
            rvUser.setHasFixedSize(true)
            rvUser.layoutManager = LinearLayoutManager(this@MainActivity)
            rvUser.adapter = adapter
        }

        viewModel.setFavoriteUser(this)

        viewModel.getFavoriteUser()?. observe(this, Observer{
            if (it != null){
                adapter.setData(it)
            }

        })

        onClicked()

    }

    fun onClicked(){
        adapter.setOnItemClickCallBack(object : MyAdapter.OnItemClickCallback {
            override fun onItemClicked(user: User) {
                val moveProfile = Intent(this@MainActivity, FullProfileActivity::class.java)
                moveProfile.putExtra(EXTRA_USER, user)
                moveProfile.putExtra(FullProfileActivity.EXTRA_USERNAME, user.name)
                moveProfile.putExtra(FullProfileActivity.EXTRA_ID, user.id)
                moveProfile.putExtra(FullProfileActivity.EXTRA_URL, user.photo)
                moveProfile.putExtra(FullProfileActivity.EXTRA_NAME, user.detail)
                moveProfile.putExtra(FullProfileActivity.EXTRA_FOLLOWERS, user.followers)
                moveProfile.putExtra(FullProfileActivity.EXTRA_FOLLOWING, user.following)
                moveProfile.putExtra(FullProfileActivity.EXTRA_WORKPLACE, user.workplace)
                moveProfile.putExtra(FullProfileActivity.EXTRA_LOCATION, user.location)
                moveProfile.putExtra(FullProfileActivity.EXTRA_REPOSITORIES, user.repositories)
                startActivity(moveProfile)
            }
        })
    }
}