package com.project.consumerapp.view.main

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.project.consumerapp.R
import com.project.consumerapp.model.data.User
import com.project.consumerapp.viewmodel.FavoriteViewModel
import com.project.consumerapp.viewmodel.SectionPagerAdapter
import kotlinx.android.synthetic.main.activity_full_profile.*

class FullProfileActivity : AppCompatActivity() {

    private lateinit var viewModel: FavoriteViewModel

    companion object {
        @StringRes
        val TAB_TITLES = intArrayOf(
                R.string.followers,
                R.string.following
        )

        const val EXTRA_ID = "extra_id"
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_URL = "extra_url"
        const val EXTRA_NAME= "extra_name"
        const val EXTRA_FOLLOWERS ="extra_followers"
        const val EXTRA_FOLLOWING ="extra_following"
        const val EXTRA_WORKPLACE= "extra_workplace"
        const val EXTRA_LOCATION= "extra_location"
        const val EXTRA_REPOSITORIES= "extra_repositories"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_profile)


        val orientation = resources.configuration.orientation
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    viewpager.layoutParams.height = resources.getDimension(R.dimen.height).toInt()
                } else {
                    viewpager.layoutParams.height = resources.getDimension(R.dimen.height1).toInt()
                }

        if (supportActionBar != null) {
            supportActionBar?.title = "Detail"
        }
        val id = intent.getIntExtra(EXTRA_ID, 0)
        val avatarUrl = intent.getStringExtra(EXTRA_URL)
        val username = intent.getStringExtra(EXTRA_USERNAME)
        val fullName = intent.getStringExtra(EXTRA_NAME)
        val followers = intent.getStringExtra(EXTRA_FOLLOWERS)
        val following = intent.getStringExtra(EXTRA_FOLLOWING)
        val workplace = intent.getStringExtra(EXTRA_WORKPLACE)
        val location = intent.getStringExtra(EXTRA_LOCATION)
        val repositories = intent.getStringExtra(EXTRA_REPOSITORIES)

        viewModel = ViewModelProvider(this).get(FavoriteViewModel::class.java)
        setData()
    }

    private fun setData() {
        val dataUser = intent.getParcelableExtra<User>(MainActivity.EXTRA_USER)
        Glide.with(this)
            .load(dataUser?.photo)
            .apply(RequestOptions().override(150, 130))
            .into(img_item_photo_profil)
        full_name.text = dataUser?.detail
        full_detail.text = getString(R.string.yulski, dataUser?.name)
        work_place.text = dataUser?.workplace
        location_address.text = dataUser?.location
        text_following.text = dataUser?.following
        text_followers.text = dataUser?.followers
        textView.text = dataUser?.repositories


        val sectionPagerAdapter = SectionPagerAdapter(dataUser?.name as String, this, supportFragmentManager)
        viewpager.adapter = sectionPagerAdapter
        tabs.setupWithViewPager(viewpager)
        supportActionBar?.elevation = 0f
    }


}