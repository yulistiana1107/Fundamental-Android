package com.project.githubuserproject.view.settings

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.edit
import com.project.githubuserproject.R
import com.project.githubuserproject.view.settings.AlarmHelper.cancelAlarm
import com.project.githubuserproject.view.settings.AlarmHelper.setRepeatingAlarm
import kotlinx.android.synthetic.main.activity_settings.*

class SettingsActivity : AppCompatActivity(), View.OnClickListener {
    companion object {
        private const val PREFS_REMINDER = "reminder_pref"
    }
    private lateinit var preference: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        setReminderMode(this)

        val changeLanguage: TextView = findViewById(R.id.textView3)
        changeLanguage.setOnClickListener(this)
    }

    private fun setReminderMode(context: Context) {
        preference = getSharedPreferences(PREFS_REMINDER, Context.MODE_PRIVATE)
        swDaily.apply {
            isChecked = preference.getBoolean(PREFS_REMINDER, false)
            setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    setRepeatingAlarm(context,resources.getString(R.string.daily_message))
                    preference.edit { putBoolean(PREFS_REMINDER, true) }
                    Toast.makeText(context,
                            resources.getString(R.string.reminder_activated),
                            Toast.LENGTH_LONG).show()
                } else {
                    cancelAlarm(context)
                    preference.edit { putBoolean(PREFS_REMINDER, false) }
                    Toast.makeText(context,
                            resources.getString(R.string.reminder_deactivated),
                            Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onClick (v: View?) {
        when (v?.id) {
            R.id.textView3 -> {
                val moveIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(moveIntent)
            }
        }
    }
}