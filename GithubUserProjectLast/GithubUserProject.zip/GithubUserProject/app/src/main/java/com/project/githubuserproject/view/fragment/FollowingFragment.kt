package com.project.githubuserproject.view.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.githubuserproject.viewmodel.MainViewModel
import com.project.githubuserproject.viewmodel.MyAdapter
import com.project.githubuserproject.R
import com.project.githubuserproject.model.data.User
import com.project.githubuserproject.view.main.FullProfileActivity
import com.project.githubuserproject.view.main.MainActivity
import kotlinx.android.synthetic.main.fragment_following.*

class FollowingFragment(private val username: String) : Fragment() {
    companion object {
        const val EXTRA_DETAIL = "extra_detail"
    }

    private lateinit var adapter: MyAdapter
    private lateinit var mainViewModel: MainViewModel

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_following, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = MyAdapter()
        mainViewModel = ViewModelProvider(
                this, ViewModelProvider.NewInstanceFactory()
        ).get(MainViewModel::class.java)

        activity!!.intent.getParcelableExtra<User>(EXTRA_DETAIL)
        config()
        onClicked()

        mainViewModel.getDataFollowing(activity!!.applicationContext, username)
        showLoading(true)

        mainViewModel.getListUsers().observe(activity!!, Observer {followingItems ->
            if (followingItems != null) {
                adapter.setData(followingItems)
                showLoading(false)
            }
        })
    }

    fun onClicked(){
        adapter.setOnItemClickCallBack(object : MyAdapter.OnItemClickCallback {
            override fun onItemClicked(user: User) {
                activity?.let{
                    val intent = Intent (it, FullProfileActivity::class.java)
                    intent.putExtra(MainActivity.EXTRA_USER, user)
                    intent.putExtra(FullProfileActivity.EXTRA_USERNAME, user.name)
                    intent.putExtra(FullProfileActivity.EXTRA_ID, user.id)
                    intent.putExtra(FullProfileActivity.EXTRA_URL, user.photo)
                    intent.putExtra(FullProfileActivity.EXTRA_NAME, user.detail)
                    it.startActivity(intent)
                }
            }
        })
    }

    private fun config() {
        recyclerviewfollowing.layoutManager = LinearLayoutManager(activity)
        recyclerviewfollowing.setHasFixedSize(true)
        recyclerviewfollowing.adapter = adapter
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar2.visibility = View.VISIBLE
        } else {
            progressBar2.visibility = View.INVISIBLE
        }
    }
}