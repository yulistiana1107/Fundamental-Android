package com.project.githubuserproject.view.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.content.Intent
import android.view.*
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.githubuserproject.viewmodel.MainViewModel
import com.project.githubuserproject.viewmodel.MyAdapter
import com.project.githubuserproject.R
import com.project.githubuserproject.databinding.ActivityMainBinding
import com.project.githubuserproject.model.data.User
import com.project.githubuserproject.view.favorite.FavoriteActivity
import com.project.githubuserproject.view.settings.SettingsActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity(){
    companion object {
        const val EXTRA_USER = "extra_user"
    }

    private var listGithub: ArrayList<User> = ArrayList()
    private lateinit var adapter: MyAdapter
    private lateinit var binding: ActivityMainBinding
    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter= MyAdapter()
        mainViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(MainViewModel::class.java)

        searchData()
        viewConfig()
        runGetDataGit()
        onClicked()
        configMainViewModel(adapter)

        mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)
    }

    private fun viewConfig() {
        binding.profileUser.layoutManager = LinearLayoutManager(this)
        binding.profileUser.adapter = adapter

        adapter.notifyDataSetChanged()
        profileUser.adapter = adapter
    }


    private fun configMainViewModel(adapter: MyAdapter) {
        mainViewModel.getListUsers().observe(this, androidx.lifecycle.Observer {
            if (it != null) {
                adapter.setData(it)
                showLoading(false)
            }
        })
    }

    private fun runGetDataGit() {
        mainViewModel.getDataGit(applicationContext)
        showLoading(true)
    }

    private fun searchData(){
        val search = findViewById<android.widget.SearchView>(R.id.search)
        search.setOnQueryTextListener(object : android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                if (query.isNotEmpty()) {
                    listGithub.clear()
                    viewConfig()
                    mainViewModel.getDataGitSearch(query, applicationContext)
                    showLoading(true)
                } else {
                    return true
                }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
    }

    fun onClicked(){
        adapter.setOnItemClickCallBack(object : MyAdapter.OnItemClickCallback {
            override fun onItemClicked(user: User) {
                val moveProfile = Intent(this@MainActivity, FullProfileActivity::class.java)
                moveProfile.putExtra(EXTRA_USER, user)
                moveProfile.putExtra(FullProfileActivity.EXTRA_USERNAME, user.name)
                moveProfile.putExtra(FullProfileActivity.EXTRA_ID, user.id)
                moveProfile.putExtra(FullProfileActivity.EXTRA_URL, user.photo)
                moveProfile.putExtra(FullProfileActivity.EXTRA_NAME, user.detail)
                moveProfile.putExtra(FullProfileActivity.EXTRA_FOLLOWERS, user.followers)
                moveProfile.putExtra(FullProfileActivity.EXTRA_FOLLOWING, user.following)
                moveProfile.putExtra(FullProfileActivity.EXTRA_WORKPLACE, user.workplace)
                moveProfile.putExtra(FullProfileActivity.EXTRA_LOCATION, user.location)
                moveProfile.putExtra(FullProfileActivity.EXTRA_REPOSITORIES, user.repositories)
                startActivity(moveProfile)
            }
        })
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        setMode(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun setMode(selectedMode: Int) {
        when (selectedMode) {

            R.id.menu -> {
                val bioData = Intent(this@MainActivity, LoginActivity::class.java)
                startActivity(bioData)
            }

            R.id.favorite_menu ->{
                val favorite = Intent(this@MainActivity, FavoriteActivity::class.java)
                startActivity(favorite)
            }

            R.id.settings_menu ->{
                val settings = Intent(this@MainActivity, SettingsActivity::class.java)
                startActivity(settings)
            }
        }
    }
}