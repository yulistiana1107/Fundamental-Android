package com.project.githubuserproject.view.main

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ToggleButton
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.project.githubuserproject.R
import com.project.githubuserproject.viewmodel.SectionPagerAdapter
import com.project.githubuserproject.model.data.User
import com.project.githubuserproject.viewmodel.DetailUserViewModel
import kotlinx.android.synthetic.main.activity_full_profile.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FullProfileActivity : AppCompatActivity() {

    private lateinit var viewModel: DetailUserViewModel
    private lateinit var btnToggleButton: ToggleButton

    companion object {
        @StringRes
        val TAB_TITLES = intArrayOf(
                R.string.followers,
                R.string.following
        )

        const val EXTRA_ID = "extra_id"
        const val EXTRA_USERNAME = "extra_username"
        const val EXTRA_URL = "extra_url"
        const val EXTRA_NAME= "extra_name"
        const val EXTRA_FOLLOWERS ="extra_followers"
        const val EXTRA_FOLLOWING ="extra_following"
        const val EXTRA_WORKPLACE= "extra_workplace"
        const val EXTRA_LOCATION= "extra_location"
        const val EXTRA_REPOSITORIES= "extra_repositories"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_profile)

        btnToggleButton = findViewById(R.id.togglefavorite)

        val orientation = resources.configuration.orientation
                if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    viewpager.layoutParams.height = resources.getDimension(R.dimen.height).toInt()
                } else {
                    viewpager.layoutParams.height = resources.getDimension(R.dimen.height1).toInt()
                }

        if (supportActionBar != null) {
            supportActionBar?.title = "Detail"
        }
        val id = intent.getIntExtra(EXTRA_ID, 0)
        val avatarUrl = intent.getStringExtra(EXTRA_URL)
        val username = intent.getStringExtra(EXTRA_USERNAME)
        val fullName = intent.getStringExtra(EXTRA_NAME)
        val followers = intent.getStringExtra(EXTRA_FOLLOWERS)
        val following = intent.getStringExtra(EXTRA_FOLLOWING)
        val workplace = intent.getStringExtra(EXTRA_WORKPLACE)
        val location = intent.getStringExtra(EXTRA_LOCATION)
        val repositories = intent.getStringExtra(EXTRA_REPOSITORIES)

        viewModel = ViewModelProvider(this).get(DetailUserViewModel::class.java)

        var isChecked = false
        CoroutineScope(Dispatchers.IO).launch {
            val count = viewModel.checkUser(id)
            withContext(Dispatchers.Main){
                if (count != null){
                    if (count>0){
                        btnToggleButton.isChecked =  true
                        isChecked = true
                    }else{
                        btnToggleButton.isChecked =  false
                        isChecked = false
                    }
                }
            }
        }

        btnToggleButton.setOnClickListener{
            isChecked = !isChecked
            if (isChecked){
                username?.let { it1 -> avatarUrl?.let { it2 -> fullName?.let { it3 -> followers?.let { it4 -> following?.let { it5 -> workplace?.let { it6 -> location?.let { it7 -> repositories?.let { it8 -> viewModel.addToFavorite(it1, id, it2, it3, it4, it5, it6, it7, it8) } } } } } } } }
            } else{
                viewModel.removeFromFavorite(id)
            }
            btnToggleButton.isChecked = isChecked
        }
        setData()
    }

    private fun setData() {
        val dataUser = intent.getParcelableExtra<User>(MainActivity.EXTRA_USER)
        Glide.with(this)
            .load(dataUser?.photo)
            .apply(RequestOptions().override(150, 130))
            .into(img_item_photo_profil)
        full_name.text = dataUser?.detail
        full_detail.text = getString(R.string.yulski, dataUser?.name)
        work_place.text = dataUser?.workplace
        location_address.text = dataUser?.location
        text_following.text = dataUser?.following
        text_followers.text = dataUser?.followers
        textView.text = dataUser?.repositories


        val sectionPagerAdapter = SectionPagerAdapter(dataUser?.name as String, this, supportFragmentManager)
        viewpager.adapter = sectionPagerAdapter
        tabs.setupWithViewPager(viewpager)
        supportActionBar?.elevation = 0f
    }


}